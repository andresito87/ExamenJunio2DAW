// Apartado C. Uso de las clases.

/**
 * ("Martínez Gómez, Laura", "laura@example.com", "desarrollador");
 * ("Ruiz Pérez, Carlos", "carlos@example.com", "diseñador");
 * ("López Rodríguez, Elena", "elena@example.com", "gerente");
 * ("Pérez Rodríguez, María", "maria@example.com", "desarrollador");
 * ("Lara Sánchez, Pedro", "pedro@example.com", "diseñador");
 * ("Cano Rubio, Ana", "ana@example.com", "gerente");
 */


