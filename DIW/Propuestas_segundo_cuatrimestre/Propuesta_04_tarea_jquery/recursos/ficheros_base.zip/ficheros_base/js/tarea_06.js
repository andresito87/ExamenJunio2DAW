

$(document).ready(function(){
 

    // Zona de jQuery
    $("button").on("click",function(){
     alert("Botón Pulsado")

    });

 
});
